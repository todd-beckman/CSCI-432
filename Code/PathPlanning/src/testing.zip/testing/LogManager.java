package testing;

import Path2.Logger;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import grid.Grid;
import grid.WTFGrid;
import java.io.BufferedWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import pathplanning.*;
import pathplanning.util.Point;

/**
 * An implementation of Logger that tracks an ordered list of reports and allows
 * the logs to be printed to file.
 *
 * @author Todd
 *
 */
public class LogManager implements Logger {

    public static void main(String[] args) {

        //  Settings
        int minX = 0;
        int maxX = 30;
        int minY = 0;
        int maxY = 30;

        Grid g = new WTFGrid(minX, maxX, minY, maxY);

        System.out.println(g.visualize());

        try {
            FileWriter f = new FileWriter("logs.txt");
            f.write(g.visualize());
            f.close();
        } catch (Exception e) {
        }
//        LogManager aStarLogger = new LogManager();
//        LogManager dStarLogger = new LogManager();
//
//        //  Construct the paths and their loggers
//        AStar aStar = new AStar(minX, maxX, minY, maxY, g.getObstacles(), aStarLogger);
//        DStarLite dStarLite = new DStarLite(minX, maxX, minY, maxY, g.getObstacles(), dStarLogger);
//
//        System.out.println("A*: " + Arrays.toString(aStar.pathfind(g.getStart(), g.getEnd())));
//        dStarLite.init_pathfind(g.getStart(), g.getEnd());
//
//        aStarLogger.writeToFile("astar.csv");
//
//        //  Uncomment the report method below
//        //  because this adds to the runtime
//        aStarLogger.writeSizesToFile("astarsizes.csv");
//        aStarLogger.writeStatsToFile("astarstats.csv");
//
//        //  D* Lite Pathfind
////        dStarLite.pathfind(g.getStart(), g.getEnd());
////        dStarLogger.writeToFile("dstarlite.csv");
        System.out.println("Starting A*");
        runAStar(minX, maxX, minY, maxY, g);
        System.out.println("Finished A*, starting D* Lite. Waow.");
        runDStarLite(minX, maxX, minY, maxY, g);
    }

    private final ArrayList<Log> logs = new ArrayList<Log>();
    private int stackSize = 0, logSize = 0;
    private ArrayList<Integer> stackSizes = new ArrayList<Integer>();
    private ArrayList<Integer> logSizes = new ArrayList<Integer>();

    private int numberOfPushes = 0;
    private int numberOfPops = 0;
    private int numberOfRemoves = 0;

    {   //  shoutout to Jacob
        stackSizes.add(0);
        logSizes.add(0);
    }

    /**
     * Saves a log entry
     */
    @Override
    public void report(String st, int... args) {
        logs.add(new Log(st, args));
        //  adds to runtime; uncomment to use
        logSizes.add(++logSize);
        switch (st) {
            case "push":
                stackSizes.add(++stackSize);
                numberOfPushes++;
                break;
            case "pop":
                stackSizes.add(--stackSize);
                numberOfPops++;
                break;
            case "remove":
                numberOfRemoves++;
            default:
                stackSizes.add(stackSize);
                break;
        }
    }

    public void writeStatsToFile(String filename) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
            bw.write("pushes," + numberOfPushes + "\n");
            bw.write("pops," + numberOfPops + "\n");
            bw.write("removes," + numberOfRemoves);
            bw.close();
        } catch (IOException e) {
            System.out.println("Could not write to " + filename + ". Printing to console instead.");
            System.out.println("pushes," + numberOfPushes + "\n");
            System.out.println("pops," + numberOfPops + "\n");
            System.out.println("removes," + numberOfRemoves);
        }
    }

    public void writeSizesToFile(String filename) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
            bw.write("dependent,independent\n");
            for (int i = 0; i < stackSizes.size(); i++) {
                bw.write(stackSizes.get(i) + "," + logSizes.get(i) + "\n");
            }
            bw.close();
        } catch (IOException e) {
            System.out.println("Could not write to " + filename + ". Printing to console instead.");
            System.out.println(stackSizes.toString());
            System.out.println("\n");
            System.out.println(logSizes.toString());
        }
    }

    /**
     * Writes the current logs to file
     *
     * @param filename The file to write to
     */
    public void writeToFile(String filename) {
        try {
            FileWriter writer = new FileWriter(filename);
            BufferedWriter bw = new BufferedWriter(writer);
            Log.bulkWrite(logs, bw);
            bw.close();
        } catch (IOException e) {
            System.out.println("Could not write to " + filename + ". Printing to console instead.");
            System.out.println(Log.bulkToString(logs));
        }
    }

    /**
     * A log manager that also prints to the console for each log entry.
     */
    class PrintLogManager extends LogManager {

        @Override
        public void report(String st, int... args) {
            super.report(st, args);
            System.out.println(logs.get(logs.size() - 1).toString());
        }
    }

    public static void runDStarLite(int minX, int maxX, int minY, int maxY, Grid g) {
        HashSet<Point> unknown = g.getObstacles();
        Point[] cur_path;
        LogManager dStarLogger = new LogManager();
        DStarLite dsl = new DStarLite(minX, maxX, minY, maxY, new HashSet<Point>(), dStarLogger);
        dsl.init_pathfind(g.getStart(), g.getEnd());
        System.out.println("D* Lite successful init.");
        cur_path = dsl.getPath(g.getStart());
        int path_index = 0;
        while (true) {
            while (path_index < cur_path.length
                    && !unknown.contains(cur_path[path_index])) {
                path_index++;
            }
            
            if (path_index >= cur_path.length) {
                break;
            }
            System.out.println(cur_path[path_index]);
            //found obs.
            dsl.addObs(cur_path[path_index]);
            //maybe add others?
            cur_path = dsl.getPath(cur_path[path_index - 1]);
            path_index=0;
            System.out.println("D* Lite: Another path.");
        }

        dStarLogger.writeToFile("dstar.csv");

        //  Uncomment the report method below
        //  because this adds to the runtime
        dStarLogger.writeSizesToFile("dstarsizes.csv");
        dStarLogger.writeStatsToFile("dstarstats.csv");
    }

    public static void runAStar(int minX, int maxX, int minY, int maxY, Grid g) {
        HashSet<Point> unknown = g.getObstacles();
        Point[] cur_path;
        LogManager aStarLogger = new LogManager();
        AStar astr = new AStar(minX, maxX, minY, maxY, new HashSet<Point>(), aStarLogger);
        cur_path = astr.pathfind(g.getStart(), g.getEnd());
        int path_index = 0;
        while (true) {
            while (path_index < cur_path.length
                    && !unknown.contains(cur_path[path_index])) {
                path_index++;
            }
            if (path_index >= cur_path.length) {
                break;
            }
            //found obs.
            astr.addObs(cur_path[path_index]);
            
            //maybe add others?
            cur_path = astr.pathfind(cur_path[path_index - 1], g.getEnd());
            path_index = 0;
            System.out.println("A*: Another path.");

        }
        aStarLogger.writeToFile("astar.csv");

        //  Uncomment the report method below
        //  because this adds to the runtime
        aStarLogger.writeSizesToFile("astarsizes.csv");
        aStarLogger.writeStatsToFile("astarstats.csv");
    }
}
